Hello,
thanks for using my Status Function.
I've written down all Commands, Tips, Credits and Help.



--How to install--
1. To get the function working, stop the server, then paste 	"Status.zip" in the "datapacks" folder of your world. 
	(On servers, don't paste it in the "world_nether" or "world_the_end", only in the "world" file)
2. Start the Server. 
3. If not done already, run
	"/datapack enable "file/Status.zip"
	If there is no chat message in the chat, please run "/function firstuse:firststart"

Now you should get a message in the Chat.
The setup is complete.
Let's get to the commands.


--Commands--
Basics:
/trigger StatusHelp for the Help-Menu
/trigger StatusHelp set 2 for the Credits
/trigger Status for the Team-Menu


Teams:
/trigger Status set 5   for AFK
/trigger Status set 6   for Build
/trigger Status set 69  for Cute
/trigger Status set 7   for Discord
/trigger Status set 8   for Discovering...
/trigger Status set 9   for Farm
/trigger Status set 10  for Live
/trigger Status set 11  for NoNether
/trigger Status set 12  for Rec
/trigger Status set 13  for Redstone
/trigger Status set 14  for RP 

/trigger Status set 100  to clear your Status

/trigger StatusAnimated set 1  to use animated Status
/trigger StatusAnimated set 2  to not use animated Status


Admin Stuff:
/function setup:reinstall  to reset all data and reboot the function
/function setup:remove  for the "Remove?-Menu"
	/trigger StatusKeep  doesn't remove the data
	/trigger StatusRemove  deletes all data (Scores/Scoreboards/Teams)



--Tips--
There isn't much to say here, but i'll explain what all the scoreboards do. Maybe you'll find some Eastereggs :^)

Scoreboards:
Status: A trigger for the team stuff, 1337
StatusKeep : A trigger for keeping the function
StatusRemove: A trigger for removing the function
StatusTime: Adds every tick one for every player, I use it to message every player new to the function
StatusAnimation: A dummy for the animated Teams
StatusHelp: A trigger for the Help and Credits menu
StatusAnimated2: Stores the information for who wants a animated Status
StatusAnimated: A trigger to toggle animated Status
StatusWelcome: This will look for a player to join, and say the message "Welcome Back! Your Status is..."


<-- Here is line 69 :^)

--Credits--
datapack by: thevalleyy
https://www.youtube.com/channel/UCAAHDguTiSsomnRcAqIb2dA
tellraws made with:
https://minecraft.tools/en/tellraw.php
"halo" made with:
https://github.com/kemo14331/Particle-Converter
Idea from: CraftAttack Status Plugin



--Help--
If you have any kind of problems with the datapack,
feel free to write an issue on GitHub.




~thevalleyy